# zoom-image-carousel
Zoom image gallery for product reviewing - using jQuery, JS and CSS
